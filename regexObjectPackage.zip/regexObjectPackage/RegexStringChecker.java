package regexObjectPackage;

import java.util.regex.Pattern;

public abstract class RegexStringChecker {

	private String regex;
	
	boolean checkForMatch(String input){
		
		if(this.regex != null){
			return Pattern.matches(regex, input);
		}
		else{
			System.out.print("Regex is null");
			return false;
		}
	}
	
	protected void setRegex(String regex){
		this.regex = regex;
	}
	
	public String getRegex(){
		return this.regex;
	}
	
	public abstract String toString();
}
