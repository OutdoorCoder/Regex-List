package regexObjectPackage;

public class HasDigitRegex extends RegexStringChecker{

	
	public HasDigitRegex() {
		this.setRegex(".*\\d.*");
	}
	
	@Override
	public String toString() {
		
		return("Has digit regex: \\\\d");
	}
}
