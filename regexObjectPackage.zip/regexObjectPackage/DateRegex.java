package regexObjectPackage;

public class DateRegex extends RegexStringChecker{
	
	public DateRegex(){
		this.setRegex("\\b(0[1-9]|1[012])([- /.])(0[1-9]|[12][0-9]|3[01])\\2\\d{4}\\b");
	}
	
	@Override
	public String toString() {
		return ("Date Regex: \\\\b(0[1-9]|1[012])([- /.])(0[1-9]|[12][0-9]|3[01])\\\\2\\\\d{4}\\\\b");
	}
}
