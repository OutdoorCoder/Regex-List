package regexObjectPackage;

import java.util.ArrayList;

public class RegexList {
	ArrayList<RegexStringChecker> list;
	
	public RegexList(){
		this.list = new ArrayList<RegexStringChecker>();
	}
	
	public void add(RegexStringChecker regex){
		this.list.add(regex);
	}
	
	public void remove(RegexStringChecker regex){
		this.list.remove(regex);
	}
	
	public boolean checkRegexs(String stringToCheck){

		for(RegexStringChecker item: list){
			boolean bool = item.checkForMatch(stringToCheck);
			if(bool == false)
				return false;
		}
		
		return true;
	}
	
	public String toString(){
		String ret = "";
		for(RegexStringChecker item: list){
			ret += item.toString() + " ";
		}
		
		ret.trim();
		return ret;
	}
}
